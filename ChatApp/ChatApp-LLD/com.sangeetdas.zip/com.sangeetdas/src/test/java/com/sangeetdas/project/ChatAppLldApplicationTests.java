package com.sangeetdas.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatAppLldApplicationTests {

	@Test
	void contextLoads() {
	}

}
